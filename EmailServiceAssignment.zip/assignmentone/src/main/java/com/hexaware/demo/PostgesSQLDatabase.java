package com.hexaware.demo;

import org.springframework.stereotype.Component;

@Component("postgesSQLDatabase")
public class PostgesSQLDatabase implements IDataSource {
    public void returnConnection() {
        System.out.println("PostgesSQL Connected");
    }
}
