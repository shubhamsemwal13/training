package com.hexaware.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("emailService")
public class EmailService {

    IDataSource obj1=null;

    @Autowired
    public EmailService(IDataSource t) {
        this.obj1=t;
        System.out.println("constructor injection\n" +this.obj1);
    }

    public void sendEmail() {
        obj1.returnConnection();
    }
}
