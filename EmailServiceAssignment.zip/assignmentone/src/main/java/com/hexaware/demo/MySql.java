package com.hexaware.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("mySQL")
@Primary
public class MySql implements IDataSource {

    @Override
    public void returnConnection() {
        System.out.println("MySQL database Connected");
    }
}
