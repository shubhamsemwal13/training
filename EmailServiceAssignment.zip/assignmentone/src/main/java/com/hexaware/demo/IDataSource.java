package com.hexaware.demo;

public interface IDataSource {
    public void returnConnection();
}
